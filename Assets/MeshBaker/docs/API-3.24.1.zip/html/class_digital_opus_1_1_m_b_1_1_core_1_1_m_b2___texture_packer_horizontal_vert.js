var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_horizontal_vert =
[
    [ "TexturePackingOrientation", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_horizontal_vert.html#a11e3000d28a39a5b361f52e4501d60bf", [
      [ "horizontal", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_horizontal_vert.html#a11e3000d28a39a5b361f52e4501d60bfa4505cad087312551a6fbbe6ebe163e0f", null ],
      [ "vertical", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_horizontal_vert.html#a11e3000d28a39a5b361f52e4501d60bfae6dec152d6a941fccb0a5e8cc2579cc3", null ]
    ] ],
    [ "GetRects", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_horizontal_vert.html#a647e21b0b71b1c6e44b6db25c32d8f4f", null ],
    [ "GetRects", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_horizontal_vert.html#aa8e3a4ca5efc92620622b365eb5e365d", null ],
    [ "packingOrientation", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_horizontal_vert.html#a15c77a3349b92f0ddf8879ab364b0671", null ],
    [ "stretchImagesToEdges", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_horizontal_vert.html#aa983529bf85efbf130755dd9c403e638", null ]
];