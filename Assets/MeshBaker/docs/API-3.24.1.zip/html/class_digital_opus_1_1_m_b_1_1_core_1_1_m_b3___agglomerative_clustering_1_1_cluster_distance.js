var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering_1_1_cluster_distance =
[
    [ "ClusterDistance", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering_1_1_cluster_distance.html#ac7a7c7cff870e672f4cb52819bc2e4cf", null ],
    [ "a", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering_1_1_cluster_distance.html#a944656b600cdc626b83c0b23cdf485a4", null ],
    [ "b", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering_1_1_cluster_distance.html#a4ccd2deab70f198d380d1404bdc5e936", null ]
];