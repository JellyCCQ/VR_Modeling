var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___bake_in_place =
[
    [ "BakeMeshesInPlace", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___bake_in_place.html#a90fec56de9f316b5c0b07798f3f20e74", null ],
    [ "BakeOneMesh", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___bake_in_place.html#aa43fcd5b85a1807c17299f4f81767f0f", null ]
];