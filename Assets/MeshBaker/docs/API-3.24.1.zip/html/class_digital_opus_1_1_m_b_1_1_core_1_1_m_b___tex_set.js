var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set =
[
    [ "MB_TexSet", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#adee280b1ac7648eb43594d62981d231f", null ],
    [ "AllTexturesAreSameForMerge", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#abdb9f2502aec784acf5772ba30ed3c72", null ],
    [ "CalcInitialFullSamplingRects", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#a969f494eae51493c07a62c4db1cc3cd3", null ],
    [ "CalcMatAndUVSamplingRects", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#ad21e5d8ef1232c41f3fd2de1404cf041", null ],
    [ "allTexturesUseSameMatTiling", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#a26ea75d3a3bbc93fd4f0f583f02904d7", null ],
    [ "idealHeight", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#a0af7a1d59894e235009920ada4d212e8", null ],
    [ "idealWidth", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#ac981a10bf3532f58feff369dc2151af6", null ],
    [ "matsAndGOs", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#a227eecc751cafbfc63b87a2a04465e7f", null ],
    [ "obUVoffset", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#a5b37683fbcae37409729554475ec3d7e", null ],
    [ "obUVscale", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#a00bb7bd8a1624ea8a1344c4d5f7add25", null ],
    [ "ts", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#a53870969c05b9435f21f067a6b605c28", null ],
    [ "obUVrect", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html#a0265707aaf5b3926893b883ffd408254", null ]
];