var class_digital_opus_1_1_m_b_1_1_core_1_1_mats_and_g_os =
[
    [ "gos", "class_digital_opus_1_1_m_b_1_1_core_1_1_mats_and_g_os.html#abad091f0b9c820cee0b54ffeb9c31473", null ],
    [ "mats", "class_digital_opus_1_1_m_b_1_1_core_1_1_mats_and_g_os.html#a9a3a2a90c6a5711e357dd043f33ab439", null ]
];