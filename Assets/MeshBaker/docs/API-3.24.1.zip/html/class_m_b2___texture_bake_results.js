var class_m_b2___texture_bake_results =
[
    [ "Material2AtlasRectangleMapper", "class_m_b2___texture_bake_results_1_1_material2_atlas_rectangle_mapper.html", "class_m_b2___texture_bake_results_1_1_material2_atlas_rectangle_mapper" ],
    [ "ContainsMaterial", "class_m_b2___texture_bake_results.html#afd4798311290d443b46e1c6f78e45c3d", null ],
    [ "CreateForMaterialsOnRenderer", "class_m_b2___texture_bake_results.html#a4edeb469232d0097b1c7be17a49b3d2a", null ],
    [ "DoAnyResultMatsUseConsiderMeshUVs", "class_m_b2___texture_bake_results.html#a0713bc5ff11812ae3dcf31b2ce33f286", null ],
    [ "GetDescription", "class_m_b2___texture_bake_results.html#a659069d646564b075cb17dd3d7e3812c", null ],
    [ "IsMeshAndMaterialRectEnclosedByAtlasRect", "class_m_b2___texture_bake_results.html#a9f889e2179e2dfbe2a89d4bec97eeeb2", null ],
    [ "doMultiMaterial", "class_m_b2___texture_bake_results.html#a8daec1e7c6be1cea418568072e895079", null ],
    [ "fixOutOfBoundsUVs", "class_m_b2___texture_bake_results.html#a2691265940fa5099d4d559875ba02a72", null ],
    [ "materials", "class_m_b2___texture_bake_results.html#ae22a7524e5fdaa684c3d76b170ea785e", null ],
    [ "materialsAndUVRects", "class_m_b2___texture_bake_results.html#a51b364240aea5258ecf2912b20e8517a", null ],
    [ "resultMaterial", "class_m_b2___texture_bake_results.html#ac68e917558ec2bc1a8177d02804c3878", null ],
    [ "resultMaterials", "class_m_b2___texture_bake_results.html#a314d92f8f7c83c544e1f4c4b82029fa2", null ],
    [ "version", "class_m_b2___texture_bake_results.html#a1895868eae1096bb7e8323db7d40eb5d", null ]
];