var class_m_b2___update_skinned_mesh_bounds_from_bounds =
[
    [ "objects", "class_m_b2___update_skinned_mesh_bounds_from_bounds.html#ac2f476685c29311321067657a43ca11a", null ]
];