var class_m_b3___batch_prefab_baker_1_1_m_b3___prefab_baker_row =
[
    [ "resultPrefab", "class_m_b3___batch_prefab_baker_1_1_m_b3___prefab_baker_row.html#a97584c6ff66b134ea5cb1382d8cd32d3", null ],
    [ "sourcePrefab", "class_m_b3___batch_prefab_baker_1_1_m_b3___prefab_baker_row.html#a9ca48e9855cd8b54c8984fb0f0af044c", null ]
];