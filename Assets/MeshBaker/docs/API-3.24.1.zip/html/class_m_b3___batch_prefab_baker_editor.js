var class_m_b3___batch_prefab_baker_editor =
[
    [ "UnityTransform", "class_m_b3___batch_prefab_baker_editor_1_1_unity_transform.html", "class_m_b3___batch_prefab_baker_editor_1_1_unity_transform" ],
    [ "_bakePrefabs", "class_m_b3___batch_prefab_baker_editor.html#a227c42b1914add72b653f96c68bbdfdb", null ],
    [ "_populatePrefabRowsFromTextureBaker", "class_m_b3___batch_prefab_baker_editor.html#a8f2dd24e1c8b092382e96fbae90ed08b", null ],
    [ "CreateNewBatchPrefabBaker", "class_m_b3___batch_prefab_baker_editor.html#a4b6196d8b61d902f830edf454f12ab39", null ],
    [ "OnInspectorGUI", "class_m_b3___batch_prefab_baker_editor.html#a9b0596911060e82ebca9d35f98b2eda8", null ]
];