var class_m_b3___batch_prefab_baker_editor_1_1_unity_transform =
[
    [ "UnityTransform", "class_m_b3___batch_prefab_baker_editor_1_1_unity_transform.html#afc1df5f6aaacd9cd3062fe907ddf1be9", null ],
    [ "p", "class_m_b3___batch_prefab_baker_editor_1_1_unity_transform.html#a5999ac5b283d374fd626ff26a8f13c21", null ],
    [ "q", "class_m_b3___batch_prefab_baker_editor_1_1_unity_transform.html#afa2e3c16ff59efc4d44f1f5f7cc68f0b", null ],
    [ "s", "class_m_b3___batch_prefab_baker_editor_1_1_unity_transform.html#a4f71403c6a32c1b4e0e2044671d00e98", null ],
    [ "t", "class_m_b3___batch_prefab_baker_editor_1_1_unity_transform.html#aab2be20c1c0c470cc393f561613a8187", null ]
];