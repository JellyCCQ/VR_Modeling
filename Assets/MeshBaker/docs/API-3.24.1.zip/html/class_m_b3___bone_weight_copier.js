var class_m_b3___bone_weight_copier =
[
    [ "inputGameObject", "class_m_b3___bone_weight_copier.html#a349b3697836005c2302588a903651bdc", null ],
    [ "outputFolder", "class_m_b3___bone_weight_copier.html#a696ca72a9ea26ab2605ed4caa71fd401", null ],
    [ "outputPrefab", "class_m_b3___bone_weight_copier.html#ad9c4b27c4d21c95f5e1e35f6e59eca3b", null ],
    [ "radius", "class_m_b3___bone_weight_copier.html#ace5a5faae02c94cce9aefd570d043835", null ],
    [ "seamMesh", "class_m_b3___bone_weight_copier.html#a00d93d69339a597684e2128ed40398e4", null ]
];