var class_m_b3___mesh_baker_editor_functions =
[
    [ "_OkToCreateDummyTextureBakeResult", "class_m_b3___mesh_baker_editor_functions.html#a3b88b0ed4ad4c0163aba62d2ddea5013", null ],
    [ "BakeIntoCombined", "class_m_b3___mesh_baker_editor_functions.html#a08e82b3bead43e640169dd38b5d2adbd", null ],
    [ "MakeTex", "class_m_b3___mesh_baker_editor_functions.html#a58daf7e069a6eb2a8b00aeb89356384a", null ],
    [ "RebuildPrefab", "class_m_b3___mesh_baker_editor_functions.html#ab3f03af11d1652b0782d388623bc5055", null ],
    [ "SaveMeshsToAssetDatabase", "class_m_b3___mesh_baker_editor_functions.html#a94177050209337338f65aef6c9d5f1a5", null ],
    [ "UnwrapUV2", "class_m_b3___mesh_baker_editor_functions.html#a14e1c725be945aead4243868886f9b8a", null ]
];