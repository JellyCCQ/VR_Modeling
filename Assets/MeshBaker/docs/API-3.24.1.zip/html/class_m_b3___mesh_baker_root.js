var class_m_b3___mesh_baker_root =
[
    [ "ZSortObjects", "class_m_b3___mesh_baker_root_1_1_z_sort_objects.html", "class_m_b3___mesh_baker_root_1_1_z_sort_objects" ],
    [ "DoCombinedValidate", "class_m_b3___mesh_baker_root.html#ae0f7d6bff6995284f686341f2bce00d2", null ],
    [ "GetObjectsToCombine", "class_m_b3___mesh_baker_root.html#ab043f816b1b6c1f0caaf4ae813cd9674", null ],
    [ "DO_INTEGRITY_CHECKS", "class_m_b3___mesh_baker_root.html#a7b51220ee463fb5cced5450a2026c490", null ],
    [ "sortAxis", "class_m_b3___mesh_baker_root.html#a580cdf853c8cfaf8ee11773a4afa805c", null ],
    [ "textureBakeResults", "class_m_b3___mesh_baker_root.html#ae404f7a44a7400c93cac6512ddba2510", null ]
];