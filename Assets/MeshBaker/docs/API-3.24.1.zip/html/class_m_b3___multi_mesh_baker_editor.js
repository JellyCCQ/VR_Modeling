var class_m_b3___multi_mesh_baker_editor =
[
    [ "CreateNewMeshBaker", "class_m_b3___multi_mesh_baker_editor.html#a437ca27f8ecb9773065b0b47e08e8a07", null ],
    [ "OnInspectorGUI", "class_m_b3___multi_mesh_baker_editor.html#a218ca56bb90d4732bf94049efaa1e072", null ]
];