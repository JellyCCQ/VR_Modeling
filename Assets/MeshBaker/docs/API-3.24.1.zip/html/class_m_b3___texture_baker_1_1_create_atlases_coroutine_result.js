var class_m_b3___texture_baker_1_1_create_atlases_coroutine_result =
[
    [ "isFinished", "class_m_b3___texture_baker_1_1_create_atlases_coroutine_result.html#a174edf1b3ae176cacb4d00f3276d1747", null ],
    [ "success", "class_m_b3___texture_baker_1_1_create_atlases_coroutine_result.html#a607733c51600e35ec5f00cdd653734cb", null ]
];