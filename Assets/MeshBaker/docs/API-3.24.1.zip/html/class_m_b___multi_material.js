var class_m_b___multi_material =
[
    [ "combinedMaterial", "class_m_b___multi_material.html#acbfd716a20c2eee77f05d50546347620", null ],
    [ "considerMeshUVs", "class_m_b___multi_material.html#adf031449cb4262caab5f8c61ee955124", null ],
    [ "sourceMaterials", "class_m_b___multi_material.html#a31f6f035f1fac2f3544b810792967a62", null ]
];