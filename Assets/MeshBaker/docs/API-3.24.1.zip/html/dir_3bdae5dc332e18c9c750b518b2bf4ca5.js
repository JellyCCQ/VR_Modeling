var dir_3bdae5dc332e18c9c750b518b2bf4ca5 =
[
    [ "MB3_BakeInPlace.cs", "_m_b3___bake_in_place_8cs.html", [
      [ "MB3_BakeInPlace", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___bake_in_place.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___bake_in_place" ]
    ] ],
    [ "MB3_MBVersionEditor.cs", "_m_b3___m_b_version_editor_8cs.html", [
      [ "MBVersionEditorInterface", "interface_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor_interface.html", "interface_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor_interface" ],
      [ "MBVersionEditor", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor" ]
    ] ],
    [ "MB3_MeshBakerEditorFunctions.cs", "_m_b3___mesh_baker_editor_functions_8cs.html", [
      [ "MB3_MeshBakerEditorFunctions", "class_m_b3___mesh_baker_editor_functions.html", "class_m_b3___mesh_baker_editor_functions" ]
    ] ],
    [ "MB3_TextureCombinerEditorFunctions.cs", "_m_b3___texture_combiner_editor_functions_8cs.html", [
      [ "MB3_EditorMethods", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___editor_methods" ]
    ] ],
    [ "MB_EditorUtil.cs", "_m_b___editor_util_8cs.html", [
      [ "MB_EditorUtil", "class_m_b___editor_util.html", "class_m_b___editor_util" ]
    ] ]
];