var dir_79c5407721e6f8ecf013e10c70298429 =
[
    [ "core", "dir_3bdae5dc332e18c9c750b518b2bf4ca5.html", "dir_3bdae5dc332e18c9c750b518b2bf4ca5" ],
    [ "searchFilters", "dir_a264464ffd3c247b811128d9bb28e8fe.html", "dir_a264464ffd3c247b811128d9bb28e8fe" ],
    [ "MB3_BatchPrefabBakerEditor.cs", "_m_b3___batch_prefab_baker_editor_8cs.html", [
      [ "MB3_BatchPrefabBakerEditor", "class_m_b3___batch_prefab_baker_editor.html", "class_m_b3___batch_prefab_baker_editor" ],
      [ "UnityTransform", "class_m_b3___batch_prefab_baker_editor_1_1_unity_transform.html", "class_m_b3___batch_prefab_baker_editor_1_1_unity_transform" ]
    ] ],
    [ "MB3_BoneWeightCopierEditor.cs", "_m_b3___bone_weight_copier_editor_8cs.html", [
      [ "MB3_BoneWeightCopierEditor", "class_m_b3___bone_weight_copier_editor.html", "class_m_b3___bone_weight_copier_editor" ]
    ] ],
    [ "MB3_DisableHiddenAnimationsEditor.cs", "_m_b3___disable_hidden_animations_editor_8cs.html", [
      [ "MB3_DisableHiddenAnimationsEditor", "class_m_b3___disable_hidden_animations_editor.html", "class_m_b3___disable_hidden_animations_editor" ]
    ] ],
    [ "MB3_GameObjectMaterialInfo.cs", "_m_b3___game_object_material_info_8cs.html", null ],
    [ "MB3_MBVersionConcreteEditor.cs", "_m_b3___m_b_version_concrete_editor_8cs.html", [
      [ "MBVersionEditorConcrete", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor_concrete.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_editor_concrete" ]
    ] ],
    [ "MB3_MeshBakerEditor.cs", "_m_b3___mesh_baker_editor_8cs.html", [
      [ "MB3_MeshBakerEditor", "class_m_b3___mesh_baker_editor.html", "class_m_b3___mesh_baker_editor" ]
    ] ],
    [ "MB3_MeshBakerEditorInternal.cs", "_m_b3___mesh_baker_editor_internal_8cs.html", [
      [ "MB3_MeshBakerEditorWindowInterface", "interface_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_editor_window_interface.html", "interface_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_editor_window_interface" ],
      [ "MB3_MeshBakerEditorInternal", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_editor_internal.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_editor_internal" ]
    ] ],
    [ "MB3_MeshBakerEditorWindow.cs", "_m_b3___mesh_baker_editor_window_8cs.html", [
      [ "MB3_MeshBakerEditorWindow", "class_m_b3___mesh_baker_editor_window.html", "class_m_b3___mesh_baker_editor_window" ]
    ] ],
    [ "MB3_MeshBakerGrouperEditor.cs", "_m_b3___mesh_baker_grouper_editor_8cs.html", [
      [ "MB3_MeshBakerGrouperEditor", "class_m_b3___mesh_baker_grouper_editor.html", "class_m_b3___mesh_baker_grouper_editor" ]
    ] ],
    [ "MB3_MultiMeshBakerEditor.cs", "_m_b3___multi_mesh_baker_editor_8cs.html", [
      [ "MB3_MultiMeshBakerEditor", "class_m_b3___multi_mesh_baker_editor.html", "class_m_b3___multi_mesh_baker_editor" ]
    ] ],
    [ "MB3_SearchFilters.cs", "_m_b3___search_filters_8cs.html", [
      [ "IGroupByFilter", "interface_digital_opus_1_1_m_b_1_1_core_1_1_i_group_by_filter.html", "interface_digital_opus_1_1_m_b_1_1_core_1_1_i_group_by_filter" ],
      [ "GameObjectFilterInfo", "class_digital_opus_1_1_m_b_1_1_core_1_1_game_object_filter_info.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_game_object_filter_info" ]
    ] ],
    [ "MB3_ShaderTexturePropertyDrawer.cs", "_m_b3___shader_texture_property_drawer_8cs.html", [
      [ "MB3_ShaderTexturePropertyDrawer", "class_m_b3___shader_texture_property_drawer.html", "class_m_b3___shader_texture_property_drawer" ]
    ] ],
    [ "MB3_TextureBakerEditor.cs", "_m_b3___texture_baker_editor_8cs.html", [
      [ "MB3_TextureBakerEditor", "class_m_b3___texture_baker_editor.html", "class_m_b3___texture_baker_editor" ]
    ] ],
    [ "MB3_TextureBakerEditorInternal.cs", "_m_b3___texture_baker_editor_internal_8cs.html", [
      [ "MB3_TextureBakerEditorInternal", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_baker_editor_internal.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_baker_editor_internal" ],
      [ "MultiMatSubmeshInfo", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_baker_editor_internal_1_1_multi_mat_submesh_info.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_baker_editor_internal_1_1_multi_mat_submesh_info" ]
    ] ]
];