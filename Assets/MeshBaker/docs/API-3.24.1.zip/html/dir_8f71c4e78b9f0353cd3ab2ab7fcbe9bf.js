var dir_8f71c4e78b9f0353cd3ab2ab7fcbe9bf =
[
    [ "MB2_TexturePacker.cs", "_m_b2___texture_packer_8cs.html", [
      [ "AtlasPadding", "struct_digital_opus_1_1_m_b_1_1_core_1_1_atlas_padding.html", "struct_digital_opus_1_1_m_b_1_1_core_1_1_atlas_padding" ],
      [ "AtlasPackingResult", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result" ],
      [ "MB2_TexturePacker", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer" ],
      [ "MB2_TexturePackerRegular", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_regular.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_regular" ]
    ] ],
    [ "MB2_TexturePackerHorizontalVert.cs", "_m_b2___texture_packer_horizontal_vert_8cs.html", [
      [ "MB2_TexturePackerHorizontalVert", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_horizontal_vert.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer_horizontal_vert" ]
    ] ],
    [ "MB3_AtlasPackerRenderTexture.cs", "_m_b3___atlas_packer_render_texture_8cs.html", [
      [ "MB_TextureCombinerRenderTexture", "class_m_b___texture_combiner_render_texture.html", "class_m_b___texture_combiner_render_texture" ],
      [ "MB3_AtlasPackerRenderTexture", "class_m_b3___atlas_packer_render_texture.html", "class_m_b3___atlas_packer_render_texture" ]
    ] ],
    [ "MB3_ITextureCombinerCalculateAtlasRects.cs", "_m_b3___i_texture_combiner_calculate_atlas_rects_8cs.html", null ],
    [ "MB3_ITextureCombinerPacker.cs", "_m_b3___i_texture_combiner_packer_8cs.html", null ],
    [ "MB3_TextureCombiner.cs", "_m_b3___texture_combiner_8cs.html", [
      [ "ShaderTextureProperty", "class_digital_opus_1_1_m_b_1_1_core_1_1_shader_texture_property.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_shader_texture_property" ],
      [ "MB3_TextureCombiner", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner" ],
      [ "CombineTexturesIntoAtlasesCoroutineResult", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_combine_textures_into_atlases_coroutine_result.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_1_1_combine_textures_into_atlases_coroutine_result" ]
    ] ],
    [ "MB3_TextureCombinerAtlasRect.cs", "_m_b3___texture_combiner_atlas_rect_8cs.html", [
      [ "MeshBakerMaterialTexture", "class_digital_opus_1_1_m_b_1_1_core_1_1_mesh_baker_material_texture.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_mesh_baker_material_texture" ],
      [ "MatAndTransformToMerged", "class_digital_opus_1_1_m_b_1_1_core_1_1_mat_and_transform_to_merged.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_mat_and_transform_to_merged" ],
      [ "MatsAndGOs", "class_digital_opus_1_1_m_b_1_1_core_1_1_mats_and_g_os.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_mats_and_g_os" ],
      [ "MB_TexSet", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___tex_set" ],
      [ "ProceduralMaterialInfo", "class_digital_opus_1_1_m_b_1_1_core_1_1_procedural_material_info.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_procedural_material_info" ]
    ] ],
    [ "MB3_TextureCombinerCalculateAtlasRectsStandard.cs", "_m_b3___texture_combiner_calculate_atlas_rects_standard_8cs.html", null ],
    [ "MB3_TextureCombinerMerging.cs", "_m_b3___texture_combiner_merging_8cs.html", [
      [ "MB3_TextureCombinerMerging", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_merging.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_merging" ]
    ] ],
    [ "MB3_TextureCombinerNonTextureProperties.cs", "_m_b3___texture_combiner_non_texture_properties_8cs.html", [
      [ "MB3_TextureCombinerNonTextureProperties", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_non_texture_properties.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_non_texture_properties" ]
    ] ],
    [ "MB3_TextureCombinerPackerMeshBaker.cs", "_m_b3___texture_combiner_packer_mesh_baker_8cs.html", null ],
    [ "MB3_TextureCombinerPackerMeshBakerFast.cs", "_m_b3___texture_combiner_packer_mesh_baker_fast_8cs.html", null ],
    [ "MB3_TextureCombinerPackerUnity.cs", "_m_b3___texture_combiner_packer_unity_8cs.html", null ],
    [ "MB3_TextureCombinerPipeline.cs", "_m_b3___texture_combiner_pipeline_8cs.html", [
      [ "MB3_TextureCombinerPipeline", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_pipeline.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_pipeline" ],
      [ "CreateAtlasForProperty", "struct_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_pipeline_1_1_create_atlas_for_property.html", "struct_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_pipeline_1_1_create_atlas_for_property" ]
    ] ]
];