var dir_a264464ffd3c247b811128d9bb28e8fe =
[
    [ "MB3_GroupByAlreadyAdded.cs", "_m_b3___group_by_already_added_8cs.html", [
      [ "GroupByAlreadyAdded", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_already_added.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_already_added" ]
    ] ],
    [ "MB3_GroupByEnabledDisabled.cs", "_m_b3___group_by_enabled_disabled_8cs.html", [
      [ "GroupByEnabledDisabled", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_enabled_disabled.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_enabled_disabled" ]
    ] ],
    [ "MB3_GroupByLightmapIndex.cs", "_m_b3___group_by_lightmap_index_8cs.html", [
      [ "GroupByLightmapIndex", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_lightmap_index.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_lightmap_index" ]
    ] ],
    [ "MB3_GroupByMaterial.cs", "_m_b3___group_by_material_8cs.html", [
      [ "GroupByMaterial", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_material.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_material" ]
    ] ],
    [ "MB3_GroupByOutOfBoundsUVs.cs", "_m_b3___group_by_out_of_bounds_u_vs_8cs.html", [
      [ "GroupByOutOfBoundsUVs", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_out_of_bounds_u_vs.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_out_of_bounds_u_vs" ]
    ] ],
    [ "MB3_GroupByRenderType.cs", "_m_b3___group_by_render_type_8cs.html", [
      [ "GroupByRenderType", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_render_type.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_render_type" ]
    ] ],
    [ "MB3_GroupByShader.cs", "_m_b3___group_by_shader_8cs.html", [
      [ "GroupByShader", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_shader.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_shader" ]
    ] ],
    [ "MB3_GroupByStandardShaderType.cs", "_m_b3___group_by_standard_shader_type_8cs.html", [
      [ "MB3_GroupByStandardShaderType", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___group_by_standard_shader_type.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___group_by_standard_shader_type" ]
    ] ],
    [ "MB3_GroupByStatic.cs", "_m_b3___group_by_static_8cs.html", [
      [ "GroupByStatic", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_static.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_static" ]
    ] ]
];